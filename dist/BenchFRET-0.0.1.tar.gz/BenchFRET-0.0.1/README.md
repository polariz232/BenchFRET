# BenchFRET
master project on smFRET analysis, benchmarking HMM, baysian and Deep learning tools 
